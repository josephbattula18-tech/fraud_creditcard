import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.ensemble import RandomForestClassifier

# =========================
# LOAD DATASET
# =========================
data = pd.read_csv("BankChurners.csv")

print("Dataset Shape:", data.shape)
print("Columns:\n", data.columns)

# =========================
# TARGET VARIABLE
# =========================
# Attrition_Flag:
# Existing Customer -> 0 (Normal)
# Attrited Customer -> 1 (Fraud / Risk)
data["Attrition_Flag"] = data["Attrition_Flag"].map({
    "Existing Customer": 0,
    "Attrited Customer": 1
})

# =========================
# DROP UNNECESSARY COLUMNS
# =========================
drop_cols = ["CLIENTNUM"]
data.drop(columns=drop_cols, inplace=True)

# =========================
# HANDLE CATEGORICAL DATA
# =========================
label_encoder = LabelEncoder()

categorical_cols = data.select_dtypes(include=["object"]).columns

for col in categorical_cols:
    data[col] = label_encoder.fit_transform(data[col])

# =========================
# FEATURES & TARGET
# =========================
X = data.drop("Attrition_Flag", axis=1)
y = data["Attrition_Flag"]

# =========================
# TRAIN-TEST SPLIT
# =========================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# =========================
# FEATURE SCALING
# =========================
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# =========================
# MODEL: RANDOM FOREST
# =========================
model = RandomForestClassifier(
    n_estimators=200,
    random_state=42,
    class_weight="balanced"
)

model.fit(X_train, y_train)

# =========================
# PREDICTION
# =========================
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# =========================
# EVALUATION
# =========================
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

print("ROC-AUC Score:", roc_auc_score(y_test, y_prob))

# =========================
# CONFUSION MATRIX
# =========================
cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()

# =========================
# FEATURE IMPORTANCE
# =========================
feature_importance = pd.Series(
    model.feature_importances_, index=X.columns
).sort_values(ascending=False)

plt.figure(figsize=(8,5))
feature_importance.head(10).plot(kind="bar")
plt.title("Top 10 Important Features")
plt.ylabel("Importance")
plt.show()
